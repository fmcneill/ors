nonFacts([class,member,assert]).

myFacts([calculuation]).

transitivePreds([]).

inform([]).



predSubclass(action,thing).
predSubclass(inform,predicate).
