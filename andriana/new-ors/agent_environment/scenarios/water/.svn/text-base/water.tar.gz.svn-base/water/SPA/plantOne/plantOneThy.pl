:- dynamic fact/1,class/2.

class(plantZero,agent).
class(plantOne,agent).

fact(treats(plantZero,alpha)).
fact(at(plantOne,alpha)).
fact(not(at(plantZero,alpha))).




