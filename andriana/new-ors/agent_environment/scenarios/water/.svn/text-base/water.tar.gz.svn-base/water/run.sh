killall sicstus
xterm -bg "#FFFFFF" -e sicstus -l ../../server.pl &
sleep 2
xterm -bg "#52657F" -fg "#FFFFFF" -geometry "40x12+0+0" -e sicstus -l SPA/plantOne/plantOne.pl &

sleep 1

xterm -bg "#AFCCF4" -fg "#000000" -geometry "+300+400" -e sicstus -l PA-onts/water_pa.pl &
